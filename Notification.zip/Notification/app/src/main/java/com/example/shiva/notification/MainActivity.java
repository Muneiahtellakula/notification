package com.example.shiva.notification;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
NotificationManager nm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nm= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    public void nofi(View view) {
        NotificationCompat.Builder notification=new NotificationCompat.Builder(this)
                .setContentTitle("Notification")
                .setContentText("this notification Text")
                .setSmallIcon(R.mipmap.ic_launcher);
        notification.setDefaults(Notification.DEFAULT_ALL);
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,1,i,PendingIntent.FLAG_UPDATE_CURRENT);
        notification.setContentIntent(pi);
        notification.setPriority(NotificationCompat.PRIORITY_HIGH);
        notification.addAction(R.mipmap.ic_launcher,"Reply",null);
        nm.notify(1, notification.build());


    }
}
